//
//  PaletteApp.swift
//  Palette
//
//  Created by 樊宸嘉 on 2022/2/12.
//

import SwiftUI

@main
struct PaletteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
