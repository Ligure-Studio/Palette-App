import SwiftUI

struct PaletteHEX: View {
    
    @State private var bgColor =
    Color(red: 84/255.0,green: 185/255.0, blue: 179/255.0)
    
    var body: some View {
        VStack {
            ColorPicker("拾色器", selection: $bgColor)
                .scaleEffect(CGSize(width: 10, height: 10))
                .labelsHidden()
        }
        .navigationTitle("十六进制调色")
    }
}

struct PaletteHEX_Previews: PreviewProvider {
    static var previews: some View {
        PaletteHEX()
    }
}
