import SwiftUI

struct NavigationMenu: View {
    let intro = Intro()
    let palette = Palette()
    let palettehex = PaletteHEX()
    let paletteduo = PaletteDuo()
    let mycolors = MyColors()
    var body: some View {
        Form{
            Section(header:Text("概览")){
                NavigationLink(destination:intro) {
                    HStack{
                        Image(systemName: "ellipsis")
                            .foregroundColor(Color(red: 84/255.0, green: 185/255.0, blue: 179/255.0))
                            .shadow(color: Color.gray, radius: 1)
                        Text("初步了解")
                    }
                }
            }
            Section(header:Text("主要功能")) {
                NavigationLink(destination:palette) {
                    HStack {
                        Image(systemName: "paintpalette")
                            .foregroundColor(Color(red: 84/255.0, green: 185/255.0, blue: 179/255.0))
                            .shadow(color: Color.gray, radius: 1)
                        Text("色度混合")
                    }
                }
                NavigationLink(destination:paletteduo) {
                    HStack {
                        Image(systemName: "paintpalette.fill")
                            .foregroundColor(Color(red: 84/255.0, green: 185/255.0, blue: 179/255.0))
                            .shadow(color: Color.gray, radius: 1)
                        Text("多色调色板")
                    }
                }
            }
            Section(header:Text("测试功能")) {
                NavigationLink(destination:palettehex) {
                    HStack {
                        Image(systemName: "paintpalette")
                            .foregroundColor(Color(red: 84/255.0, green: 185/255.0, blue: 179/255.0))
                            .shadow(color: Color.gray, radius: 1)
                        Text("Hex调色")
                    }
                }
                NavigationLink(destination:mycolors) {
                    HStack {
                        Image(systemName: "bag.circle")
                            .foregroundColor(Color(red: 84/255.0, green: 185/255.0, blue: 179/255.0))
                            .shadow(color: Color.gray, radius: 1)
                        Text("实用色彩库")
                    }
                }
            }
        }
    }
}

struct NavigationMenu_Previews: PreviewProvider {
    static var previews: some View {
        NavigationMenu()
    }
}
