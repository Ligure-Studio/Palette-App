import SwiftUI

/*
 SGksIEknbSBnbGFkIHlvdSBzb2x2ZWQgdGhlIHB1enpsZSBJIGxlZnQuIEFsdGhvdWdoIHRoZSBhcHBsaWNhdGlvbiB0aGlzIHRpbWUgaXMgbGlnaHR3ZWlnaHQsIGl0IGhhcyBhIGxvdCBvZiBkZXZlbG9wbWVudCBhbmQgaW52b2x2ZXMgbWFueSBrbm93bGVkZ2UgYmxpbmQgc3BvdHMuIEknbSB2ZXJ5IGhhcHB5IHRvIGhhdmUgdGhlIGN1cnJlbnQgY29tcGxldGlvbiBiZWZvcmUgdGhlIGVuZCBvZiB0aGUgd2ludGVyIHZhY2F0aW9uLiBJIGFsc28gaG9wZSB5b3UgY2FuIGJlIGhhcHB5IHdoZW4gdXNpbmcgbXkgYXBwbGljYXRpb24uIFRoZSBwdXJwb3NlIG9mIGRldmVsb3BpbmcgYXBwbGljYXRpb25zIGlzIG5vdCB0byB3aW4gYXdhcmRzLCBidXQgdG8gbWFrZSBwZW9wbGUgbGl2ZSBhbmQgY3JlYXRlIGJldHRlciEgQmVzdCB3aXNoZXMgdG8geW91IQ==
 
 -> Base64
 */

struct Intro: View {
    var body: some View {
        ScrollView {
            VStack {
                Image("Icon")
                Text("调色板")
                    .font(.title)
                    .padding(.top)
                Text("轻量化色彩方案生成")
                    .font(.title2)
                    .padding()
                Divider()
                Text("    调色板是由杭州绿城育华学校樊宸嘉独立开发设计。本软件使用Apple最新最先进的编程架构——SwiftUI编写，是一款轻量化的优秀色彩方案生成工具。")
                Spacer()
                Text("    本软件的开发初衷是为非专业设计者智能生成渐变色方案，通过并非十分复杂且计算量大的算法提供最方便的使用体验。软件前端干净极简，您只需要轻点按钮，拖动滑块就可以生成您喜欢的颜色，并将其运用进您的设计作品中。未来还会提供实用色彩库的一键调用和自定义存储。")
            }.padding()
        }
        }
}

struct Intro_Previews: PreviewProvider {
    static var previews: some View {
        Intro()
    }
}

