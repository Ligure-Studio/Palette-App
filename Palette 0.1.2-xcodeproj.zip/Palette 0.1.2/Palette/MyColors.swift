import SwiftUI

struct MyColors: View {
    var body: some View {
        List {
            Section(header:Text("Tips")) {
                Text("点按以复制色值，结果可能有轻微误差")
            }
            Button(action: {
                UIPasteboard.general.string = "RGB色值：103,103,166"
            }){
                HStack {
                    Image(systemName: "paintpalette.fill")
                    Text("长春花蓝")
                }
                .foregroundColor(Color(red: 103/255.0, green: 103/255.0, blue: 166/255.0))
            }
            
            
            Button(action: {
                UIPasteboard.general.string = "RGB色值：242,224,166"
            }){
                HStack {
                    Image(systemName: "paintpalette.fill")
                    Text("亮丽黄")
                }
                .foregroundColor(Color(red: 242/255.0, green: 224/255.0, blue: 104/255.0))
            }
            
            Button(action: {
                UIPasteboard.general.string = "RGB色值：147,150,152"
            }){
                HStack {
                    Image(systemName: "paintpalette.fill")
                    Text("极致灰")
                }
                .foregroundColor(Color(red: 147/255.0, green: 150/255.0, blue: 152/255.0))
            }
            
            Button(action: {
                UIPasteboard.general.string = "RGB色值：35,75,125"
            }){
                HStack {
                    Image(systemName: "paintpalette.fill")
                    Text("克莱因蓝")
                }
                .foregroundColor(Color(red: 35/255.0, green: 75/255.0, blue: 125/255.0))
            }
            
            
        }
        .navigationTitle("潘通年度色")
    }
}

struct MyColors_Previews: PreviewProvider {
    static var previews: some View {
        MyColors()
    }
}
